import entities.ArticleConfection;
import entities.Categorie;
import repositories.ITables;
import repositories.list.TableArticleConfections;
import repositories.list.TableCategories;
import services.ArticleConfectionService;
import services.ArticleConfectionServiceImpl;
import services.CategorieService;
import services.CategorieServiceImpl;

import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Choisissez une option :");
        System.out.println("1 - Gérer les catégories");
        System.out.println("2 - Gérer les articles de confection");
        System.out.println("3 - Quitter");

        int choix = scanner.nextInt();
        scanner.nextLine();

        switch (choix) {
            case 1:
                gestionCategories();
                break;
            case 2:
                gestionArticlesConfection();
                break;
            case 3:
                System.out.println("Au revoir !");
                break;
            default:
                System.out.println("Option invalide. Veuillez choisir 1, 2 ou 3.");
                break;
        }
    }

    private static void gestionCategories() {
        ITables<Categorie> categorieRepository = new TableCategories();
        CategorieServiceImpl categorieServiceImpl = new CategorieServiceImpl(categorieRepository);
        int id = 1;
        Scanner scanner = new Scanner(System.in);
    
        int choix;
        do {
            System.out.println("Menu Catégories:");
            System.out.println("1-Ajouter une catégorie");
            System.out.println("2-Modifier une catégorie");
            System.out.println("3-Supprimer une catégorie");
            System.out.println("4-Lister les catégories");
            System.out.println("5-Quitter");
            choix = scanner.nextInt();
            scanner.nextLine();
    
            switch (choix) {
                case 1:
                    System.out.println("Entrez le libellé de la catégorie :");
                    String libelle = scanner.nextLine();
                    Categorie categorie = new Categorie(id, libelle);
                    categorieServiceImpl.add(categorie);
                    id++;
                    break;
                case 2:
                    System.out.println("Entrez l'ID de la catégorie à modifier :");
                    int categorieId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Entrez le nouveau libellé :");
                    String nouveauLibelle = scanner.nextLine();
                    Categorie categorieModifiee = new Categorie(categorieId, nouveauLibelle);
                    categorieServiceImpl.update(categorieModifiee);
                    break;
                case 3:
                    System.out.println("Entrez l'ID de la catégorie à supprimer :");
                    int categorieIdToDelete = scanner.nextInt();
                    scanner.nextLine();
                    categorieServiceImpl.remove(categorieIdToDelete);
                    break;
                case 4:
                    categorieServiceImpl.getAll().forEach(System.out::println);
                    break;
                default:
                    break;
            }
        } while (choix != 5);
    }
    
    private static void gestionArticlesConfection() {
        ITables<ArticleConfection> articleRepository = new TableArticleConfections();
        ArticleConfectionServiceImpl articleServiceImpl = new ArticleConfectionServiceImpl(articleRepository);
        int id = 1;
        Scanner scanner = new Scanner(System.in);
    
        int choix;
        do {
            System.out.println("Menu Articles de Confection:");
            System.out.println("1-Ajouter un article de confection");
            System.out.println("2-Modifier un article de confection");
            System.out.println("3-Supprimer un article de confection");
            System.out.println("4-Lister les articles de confection");
            System.out.println("5-Quitter");
            choix = scanner.nextInt();
            scanner.nextLine();
    
            switch (choix) {
                case 1:
                    System.out.println("Entrez le nom de l'article :");
                    String nomArticle = scanner.nextLine();
                    System.out.println("Entrez le prix de l'article :");
                    double prixArticle = scanner.nextDouble();
                    System.out.println("Entrez la quantité de l'article :");
                    int quantiteArticle = scanner.nextInt();
                    scanner.nextLine();
                    ArticleConfection article = new ArticleConfection(id, nomArticle, prixArticle, quantiteArticle);
                    articleServiceImpl.add(article);
                    id++;
                    break;
                case 2:
                    System.out.println("Entrez l'ID de l'article à modifier :");
                    int articleId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Entrez le nouveau nom de l'article :");
                    String nouveauNomArticle = scanner.nextLine();
                    System.out.println("Entrez le nouveau prix de l'article :");
                    double nouveauPrixArticle = scanner.nextDouble();
                    System.out.println("Entrez la nouvelle quantité de l'article :");
                    int nouvelleQuantiteArticle = scanner.nextInt();
                    scanner.nextLine();
                    ArticleConfection articleModifie = new ArticleConfection(articleId, nouveauNomArticle, nouveauPrixArticle, nouvelleQuantiteArticle);
                    articleServiceImpl.update(articleModifie);
                    break;
                case 3:
                    System.out.println("Entrez l'ID de l'article à supprimer :");
                    int articleIdToDelete = scanner.nextInt();
                    scanner.nextLine();
                    articleServiceImpl.remove(articleIdToDelete);
                    break;
                case 4:
                    articleServiceImpl.getAll().forEach(System.out::println);
                    break;
                default:
                    break;
            }
        } while (choix != 5);
    }
    
}
