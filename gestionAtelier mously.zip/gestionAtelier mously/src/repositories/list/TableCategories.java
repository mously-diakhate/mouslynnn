package repositories.list;

import entities.Categorie;

public class TableCategories extends Table<Categorie> {

}
