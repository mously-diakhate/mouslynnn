package services;


import entities.Categorie;

public interface CategorieService extends IService<Categorie> {
    
}
